﻿window.CONFIG = {
  name: 'Dai Festa Decorações', whatsapp: '5521986550240', phone: '+55 (21) 98655-0240', logo: 'assets/logo.png',
  durationNotice: 'Brinquedos infláveis e estações: aluguel por até 4 horas.',
  categories: [
    {id:'decoracoes',name:'Decorações'}, {id:'inflaveis',name:'Brinquedos infláveis',maxHours:4},
    {id:'brinquedos',name:'Pula-pula e outros brinquedos'}, {id:'moveis',name:'Mesas e cadeiras'},
    {id:'estacoes',name:'Estações de alimentação',maxHours:4}
  ],
  products: []
};
// IDs são permanentes: não os altere após publicar. Imagens referem-se à pasta assets.
const photo = n => `assets/foto-${String(n).padStart(2,'0')}.webp`;
const add = (id,name,category,images,description,icon='✧') => CONFIG.products.push({id,name,category,images:images.map(photo),description,icon});
[
 ['DEC-01','Chá de bebê azul',1],['DEC-02','O Maior Pintor do Mundo',2],['DEC-03','Aniversário colorido • painel de frases',3],
 ['DEC-04','Tigrinha tropical',4],['DEC-05','Neon • asas coloridas',5],['DEC-06','Patrulha Canina • rosa e lilás',6],
 ['DEC-07','Rosa e prata',7],['DEC-08','Baby Looney Tunes',8],['DEC-09','Rei Leão',11],['DEC-10','Chá de cozinha • rosa e vinho',14],
 ['DEC-11','Decoração temática Fini',15],['DEC-12','Masha e o Urso',16],['DEC-13','Prata e branco',17],['DEC-14','Avatar e Minions',18],
 ['DEC-15','Preto e branco • laços',19],['DEC-16','Patrulha Canina • azul',20],['DEC-17','Cerejas',21],['DEC-18','Rosa e laranja',22],
 ['DEC-19','Amarelo, branco e dourado',23],['DEC-20','Verde e flores em tons terrosos',24],['DEC-21','Aniversário colorido • estilo descontraído',25],
 ['DEC-22','Ursinho Pooh e Tigrão',26],['DEC-23','Fundo do mar • azul',27],['DEC-24','Chá de bebê lilás',28],['DEC-25','Princesa Tiana',29],
 ['DEC-26','Verde e dourado',30],['DEC-27','Roxo e lilás',31],['DEC-28','Chá de bebê rosa',33]
].forEach(([id,name,n])=>add(id,name,'decoracoes',[n],'Inspire sua festa nesta montagem real. Composição e itens inclusos a confirmar no orçamento.'));
add('INF-01','Multi Park colorido','inflaveis',[9,13],'Inflável colorido com obstáculos, fotografado em dois ângulos.');
add('INF-02','Inflável com tema futebol','inflaveis',[10],'Modelo com painéis de futebol. Detalhes a confirmar.');
add('INF-03','Escorregador inflável colorido','inflaveis',[12],'Modelo colorido à direita na foto. Solicitado individualmente.');
add('INF-04','Piscina de bolinhas inflável de tigre','inflaveis',[32,12],'Piscina de bolinhas inflável com tema de tigre. Modelo a confirmar no orçamento.');
add('INF-05','Inflável de tigre com escorregador','inflaveis',[12],'Modelo à esquerda na foto, com escorregador e tema de tigre.');
add('BRI-01','Cama elástica / pula-pula','brinquedos',[39,40,37,38,41],'Cama elástica com rede. Modelo e condições a confirmar.');
add('BRI-02','Piscina de bolinhas','brinquedos',[41,37,38],'Estrutura com rede e cobertura. Item individual.');
add('BRI-03','Escorregador infantil','brinquedos',[38,41],'Escorregador azul, solicitado separadamente.');
add('BRI-04','Gangorrinha','brinquedos',[32,38,41],'Gangorrinhas coloridas. Cores a confirmar.');
add('JOG-01','Mesa de sinuca','brinquedos',[34],'Mesa de jogo com tecido verde.');
add('JOG-02','Air hockey','brinquedos',[35],'Mesa de air hockey fotografada com iluminação.');
add('JOG-03','Pebolim','brinquedos',[36],'Mesa de pebolim em madeira.');
// MOV-01 a MOV-04 foram substituídos por conjuntos; quantidades antigas por peça não são convertidas em jogos.
add('MOV-05','Combo infantil','moveis',[],'Conjunto de mesa e cadeiras infantis. Solicite a quantidade de combos; composição e quantidade de cadeiras a confirmar no orçamento.');
add('MOV-06','Jogos de mesa e cadeira','moveis',[],'Conjunto de mesa e cadeiras para adultos. Solicite a quantidade de jogos; composição e quantidade de cadeiras a confirmar no orçamento.');
['Crepe','Batata frita','Pastel','Spolleto','Drink','Algodão-doce','Pipoca','Açaí','Sorvete','Finni','X-tudo','Cachorro-quente'].forEach((name,i)=>add(`EST-${String(i+1).padStart(2,'0')}`,name,'estacoes',[],`Estação de ${name}. Cardápio, atendimento e condições a confirmar.`,['◒','♧','◇','≋','♧','☁','♧','◓','♧','✧','≡','≋'][i]));


// Apresentação do catálogo: referências de temas e imagens ilustrativas autorizadas.
add('DEC-CUSTOM','Decoração com outro tema','decoracoes',[],'Conte qual tema você deseja. Vamos conversar sobre a composição da sua decoração.','✧');
for (const p of CONFIG.products) {
  if(p.category==='decoracoes') {
    p.imageKind='reference';
    p.theme=p.id==='DEC-CUSTOM'?'':p.name;
    if(p.id!=='DEC-CUSTOM')p.description='Referência de como montamos. Escolha este tema e combine a composição da sua festa no orçamento.';
  } else if(['inflaveis','brinquedos','estacoes'].includes(p.category)) {
    p.referenceImages=p.images;
    p.images=['assets/ilustracoes/'+p.id+'.webp'];
    p.imageKind='illustration';
    p.description=p.category==='estacoes'?'Estação de '+p.name+'. Cardápio e condições a confirmar.':'Modelo e condições a confirmar no orçamento.';
  } else if(p.category==='moveis') {
    p.images=['assets/ilustracoes/'+p.id+'.webp'];
    p.imageKind='illustration';
  } else p.imageKind='photo';
}
