(() => {
'use strict';
const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const C=window.CONFIG, products=C.products, lookup=Object.fromEntries(products.map(p=>[p.id,p]));
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const cat=p=>C.categories.find(c=>c.id===p.category), limited=p=>!!cat(p).maxHours;
const isDecoration=p=>p.category==='decoracoes';
const imageCaption=p=>p.imageKind==='illustration'?'Imagem ilustrativa criada por IA':isDecoration(p)?'Referência de montagem':'Foto real';
const period=p=>limited(p)?C.durationNotice:'Período a combinar no orçamento';
let cart={}, filter='all', query='', visible=9, galleryPhotos=[], galleryIndex=0, toastTimer;
try{const saved=JSON.parse(localStorage.getItem('dai-orcamento-v1')||'{}');for(const [id,q] of Object.entries(saved||{}))if(lookup[id]&&Number.isSafeInteger(q)&&q>0)cart[id]=q;}catch{}
let decorationKept=false;for(const id of Object.keys(cart)){if(isDecoration(lookup[id])){if(decorationKept)delete cart[id];else{cart[id]=1;decorationKept=true;}}}
const notify=text=>{clearTimeout(toastTimer);$('#toast').textContent=text;toastTimer=setTimeout(()=>$('#toast').textContent='',3500);};
const items=()=>Object.entries(cart).map(([id,q])=>({p:lookup[id],q}));
const hasLimited=()=>items().some(({p})=>limited(p));
function save(){try{localStorage.setItem('dai-orcamento-v1',JSON.stringify(cart));}catch{notify('Seu navegador não permitiu salvar a seleção. Mantenha esta página aberta.');}updateCart();invalidateReview();}
function invalidateReview(){$('#review').hidden=true;$('#party').hidden=false;$('#send').removeAttribute('href');}
function renderFilters(){$('#filters').innerHTML=[{id:'all',name:'Todos os itens'},...C.categories].map(c=>`<button data-filter="${c.id}" aria-pressed="${c.id===filter}">${esc(c.name)}</button>`).join('');}
const normalize=s=>s.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
function render(){
$('#theme-help').hidden=!['all','decoracoes'].includes(filter);
const found=products.filter(p=>(filter==='all'||p.category===filter)&&normalize(p.name+' '+p.description+' '+p.id).includes(normalize(query)));
$('#result-count').textContent=found.length+' opções para sua festa';
$('#products').innerHTML=found.slice(0,visible).map(p=>{
 const decorated=isDecoration(p), chosen=!!cart[p.id];
 const media=p.images.length?`<button class="card-photo" data-photo="${p.id}" aria-label="Ampliar ${esc(p.name)}"><img src="${p.images[0]}" alt="${esc(p.name)} — ${imageCaption(p)}" loading="lazy"><span class="zoom-label">↗ Ampliar</span></button><span class="image-caption">${imageCaption(p)}</span>`:`<div class="icon-card"><span aria-hidden="true">${p.icon}</span><small>O tema que você imaginar</small></div>`;
 return `<article class="card">${media}<div class="card-content"><div class="card-meta"><span>${esc(cat(p).name)}</span><span>${p.id}</span></div><h3>${esc(p.name)}</h3><p>${esc(p.description)}</p><div class="card-bottom"><p class="period">◷ ${esc(period(p))}</p><span class="price">Valor sob consulta</span><button class="add" data-add="${p.id}" ${decorated?'aria-pressed="'+chosen+'"':''}><span>${decorated?(chosen?'Tema escolhido ✓':p.id==='DEC-CUSTOM'?'Quero informar meu tema':'Escolher este tema'):'Adicionar ao orçamento'}</span>${decorated?'':'<b aria-hidden="true">+</b>'}</button></div></div></article>`;
}).join('')||'<p>Nenhuma opção encontrada. Tente outro nome ou tema.</p>';
$('#more').hidden=visible>=found.length;
}
function updateCart(){
const count=Object.values(cart).reduce((a,b)=>a+b,0);$$('.count').forEach(el=>el.textContent=count);
$('#cart').innerHTML=items().map(({p,q})=>`<article class="cart-row"><div><h3>${isDecoration(p)?'Tema escolhido: ':''}${esc(p.name)}</h3><small>${p.id} · ${esc(cat(p).name)}<br>${isDecoration(p)?'Referência de montagem · composição a combinar':esc(period(p))}</small><button class="remove" data-remove="${p.id}" aria-label="Remover ${esc(p.name)}">${isDecoration(p)?'Remover tema':'Remover item'}</button></div>${isDecoration(p)?'<span class="theme-marker">Decoração por tema</span>':`<div class="quantity"><button data-delta="-1" data-id="${p.id}" aria-label="Diminuir quantidade de ${esc(p.name)}" ${q===1?'disabled':''}>−</button><input data-quantity="${p.id}" aria-label="Quantidade de ${esc(p.name)}" type="number" min="1" step="1" value="${q}"><button data-delta="1" data-id="${p.id}" aria-label="Aumentar quantidade de ${esc(p.name)}">+</button></div>`}</article>`).join('')||'<p>Sua lista ainda está vazia. Escolha um tema de decoração ou adicione itens do catálogo.</p><a class="button" href="#catalogo" id="back-catalog">Explorar catálogo →</a>';
$('#cart-duration').textContent=hasLimited()?C.durationNotice:'';$('#service-fields').hidden=!hasLimited();$('#service-fields').disabled=!hasLimited();$('#party').querySelector('button[type=submit]').disabled=!count;
const needsTheme=items().some(({p})=>isDecoration(p));fields.theme.required=needsTheme;$('#theme-label').textContent=needsTheme?'Tema desejado para a decoração *':'Tema ou ocasião (opcional)';
if(needsTheme&&!fields.theme.value.trim()){const p=items().find(({p})=>isDecoration(p)).p;fields.theme.value=p.theme||'';}
}
document.addEventListener('click',e=>{const b=e.target.closest('button');if(!b)return;
if(b.dataset.add){const id=b.dataset.add,p=lookup[id];if(isDecoration(p)){for(const old of Object.keys(cart))if(isDecoration(lookup[old]))delete cart[old];cart[id]=1;fields.theme.value=p.theme||'';save();render();notify('Tema escolhido. A composição será combinada no orçamento.');if(id==='DEC-CUSTOM'){$('#budget').showModal();fields.theme.focus();}}else{if((cart[id]||0)>=Number.MAX_SAFE_INTEGER)return;cart[id]=(cart[id]||0)+1;save();notify(p.name+' adicionado ao orçamento');}}
if(b.dataset.filter){filter=b.dataset.filter;visible=9;renderFilters();render();}
if(b.hasAttribute('data-budget')){$('#budget').showModal();updateCart();}
if(b.hasAttribute('data-close'))b.closest('dialog').close();
if(b.dataset.remove){const wasDecoration=isDecoration(lookup[b.dataset.remove]);delete cart[b.dataset.remove];if(wasDecoration)fields.theme.value='';save();render();}
if(b.dataset.delta){const id=b.dataset.id;const next=cart[id]+Number(b.dataset.delta);if(Number.isSafeInteger(next)&&next>=1){cart[id]=next;save();}}
if(b.dataset.photo){const p=lookup[b.dataset.photo];openGallery(p.images,p.name);}
});
$('#cart').addEventListener('change',e=>{if(!e.target.dataset.quantity)return;const id=e.target.dataset.quantity;const q=Number(e.target.value);if(!Number.isSafeInteger(q)||q<1){e.target.value=cart[id];notify('Use uma quantidade inteira maior que zero.');return;}cart[id]=q;save();});
$('#cart').addEventListener('click',e=>{if(e.target.id==='back-catalog')$('#budget').close();});
$('#search').addEventListener('input',e=>{query=e.target.value;visible=9;render();});$('#more').onclick=()=>{visible+=12;render();};
function openGallery(images,title){galleryPhotos=images;galleryIndex=0;$('#light-title').textContent=title;showPhoto();$('#lightbox').showModal();}
function showPhoto(){$('#light-image').src=galleryPhotos[galleryIndex];$('#light-image').alt=`${$('#light-title').textContent} — foto ${galleryIndex+1} de ${galleryPhotos.length}`;$('#light-position').textContent=`${galleryIndex+1} / ${galleryPhotos.length}`;$('#prev').disabled=$('#next').disabled=galleryPhotos.length<2;}
function step(n){galleryIndex=(galleryIndex+n+galleryPhotos.length)%galleryPhotos.length;showPhoto();}
$('#prev').onclick=()=>step(-1);$('#next').onclick=()=>step(1);$('#lightbox').addEventListener('keydown',e=>{if(e.key==='ArrowRight')step(1);if(e.key==='ArrowLeft')step(-1);});
$$('dialog').forEach(d=>d.addEventListener('click',e=>{if(e.target===d){const r=d.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)d.close();}}));
const galleryProducts=['DEC-18','DEC-02','DEC-23','DEC-22','DEC-01','DEC-24','DEC-25','DEC-28'].map(id=>lookup[id]);
$('#gallery').innerHTML=galleryProducts.map(p=>`<button aria-label="Ampliar ${esc(p.name)}" data-photo="${p.id}"><img loading="lazy" src="${p.images[0]}" alt="${esc(p.name)}"></button>`).join('');
const form=$('#party'), fields=form.elements;
$$('input,select,textarea').forEach((el,i)=>{const error=el.parentElement.querySelector('.error');if(error){error.id=`field-error-${i}`;el.setAttribute('aria-describedby',error.id);}});
function today(){return new Intl.DateTimeFormat('en-CA',{timeZone:'America/Sao_Paulo',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());}
fields.date.min=today();fields.unknown.onchange=()=>{fields.date.disabled=fields.unknown.checked;fields.date.required=!fields.unknown.checked;if(fields.unknown.checked){fields.date.value='';setError(fields.date,'');}invalidateReview();};
function setError(el,text){el.setAttribute('aria-invalid',String(!!text));const error=el.parentElement.querySelector('.error');if(error)error.textContent=text;}
function validate(){let valid=true;['name','date','neighborhood','city','guests','theme'].forEach(n=>setError(fields[n],''));$('#form-error').textContent='';
const fail=(n,msg)=>{setError(fields[n],msg);if(valid)fields[n].focus();valid=false;};
if(!items().length){$('#form-error').textContent='Adicione ao menos um item ao orçamento.';valid=false;}
if(items().some(({p})=>isDecoration(p))&&!fields.theme.value.trim())fail('theme','Informe o tema desejado para sua decoração.');
if(!fields.name.value.trim())fail('name','Informe seu nome.');
if(!fields.unknown.checked){if(!fields.date.value)fail('date','Escolha a data ou marque “Ainda não defini”.');else if(fields.date.value<today())fail('date','Escolha uma data de hoje em diante.');}
if(!fields.neighborhood.value.trim())fail('neighborhood','Informe o bairro do evento.');
if(!fields.city.value.trim())fail('city','Informe a cidade do evento.');
if(fields.guests.value&&(!Number.isSafeInteger(Number(fields.guests.value))||Number(fields.guests.value)<1))fail('guests','Use um número inteiro maior que zero.');
if(hasLimited()&&!['','1','2','3','4'].includes(fields.duration.value)){$('#form-error').textContent='A duração deve ser de até 4 horas.';valid=false;}
return valid;}
function message(){const v=n=>fields[n].value.trim();let lines=[`Olá, ${C.name}! Escolhi alguns itens no site e gostaria de solicitar um orçamento.`,'','DADOS DA FESTA',`Nome: ${v('name')}`,`Data: ${fields.unknown.checked?'A definir':v('date').split('-').reverse().join('/')}`,`Horário da festa: ${v('time')||'A definir'}`,`Local: ${v('neighborhood')} — ${v('city')}`];
if(v('guests'))lines.push(`Convidados: ${v('guests')}`);if(v('theme')&&!items().some(({p})=>isDecoration(p)))lines.push(`Tema/ocasião: ${v('theme')}`);
const decoration=items().find(({p})=>isDecoration(p));
if(decoration)lines.push('','DECORAÇÃO POR TEMA','Tema desejado: '+v('theme'),'Referência escolhida: '+decoration.p.name+' ['+decoration.p.id+']','As imagens são referências de montagem. A composição e os itens inclusos serão combinados no orçamento.','Período a combinar no orçamento');
const rentals=items().filter(({p})=>!isDecoration(p));
if(rentals.length)lines.push('','ITENS ESCOLHIDOS',...rentals.map(({p,q})=>q+' × '+p.name+' ['+p.id+']'+(limited(p)?'':' — Período a combinar no orçamento')));
if(rentals.some(({p})=>p.imageKind==='illustration'))lines.push('Imagens do catálogo são ilustrativas. Modelos e condições a confirmar.');
if(hasLimited())lines.push('','INFLÁVEIS E ESTAÇÕES',`Início desejado: ${v('serviceStart')||'A definir'}`,`Duração desejada: ${v('duration')?v('duration')+(v('duration')==='1'?' hora':' horas'):'A definir (até 4 horas)'}`,C.durationNotice,'Estou ciente de que o aluguel dos brinquedos infláveis e das estações é de até 4 horas.');
if(v('notes'))lines.push('','OBSERVAÇÕES',v('notes'));
lines.push('','A disponibilidade e os valores serão confirmados pelo WhatsApp. A solicitação de orçamento não confirma a reserva.','','Podem me informar o orçamento e a disponibilidade para essa data? Gostaria também de confirmar as condições de entrega, montagem e retirada. Obrigado(a)!');return lines.join('\n');}
form.addEventListener('submit',e=>{e.preventDefault();if(!validate())return;const text=message();$('#message').textContent=text;$('#send').href=`https://wa.me/${C.whatsapp}?text=${encodeURIComponent(text)}`;form.hidden=true;$('#review').hidden=false;$('#review').scrollIntoView({block:'start'});$('#send').focus();});
form.addEventListener('input',()=>{if(!$('#review').hidden)invalidateReview();});
$('#edit').onclick=()=>{invalidateReview();form.scrollIntoView({block:'start'});fields.name.focus();};
$('#copy').onclick=async()=>{try{await navigator.clipboard.writeText($('#message').textContent);notify('Pedido copiado. Cole e envie no WhatsApp.');}catch{const t=$('#copy-fallback');t.hidden=false;t.value=$('#message').textContent;t.focus();t.select();if(document.execCommand('copy')){t.hidden=true;notify('Pedido copiado.');}else notify('Selecione o texto do pedido e copie para o WhatsApp.');}};
document.title=`${C.name} | Sua festa começa aqui`;
$('.brand').setAttribute('aria-label',`${C.name} — início`);
const brandName=C.name.replace(/\sDecorações$/,'');
$('.brand>span').innerHTML=`${esc(brandName)}<small>${C.name.endsWith('Decorações')?'DECORAÇÕES':'DECORAÇÃO & FESTAS'}</small>`;
$('footer strong').textContent=C.name;
$$('.direct').forEach(a=>{a.href=`https://wa.me/${C.whatsapp}`;if(!a.classList.contains('float-wa'))a.textContent=`WhatsApp · ${C.phone} ↗`;});
$('.float-wa').innerHTML='<svg viewBox="0 0 32 32" width="29" height="29" aria-hidden="true"><path d="M16 4a11 11 0 0 0-9.6 16.4L5 27l6.5-1.6A11 11 0 1 0 16 4Z" fill="none" stroke="currentColor" stroke-width="2"/><path d="M11 10c-2 1-1 6 2 9s7 4 9 1l-4-2-1 2c-3-1-5-3-6-6l2-1-2-3Z" fill="currentColor"/></svg>';
$('.logo').src=C.logo;
renderFilters();render();updateCart();
})();
